# bioweb-proyecto-tic
Pagina web creada para una tarea de tic que contiene en su repositorio una carpeta images, una styles con el código css, una scripts con el código js; además de un archivo README.md , un archivo LICENSE que incluye una licencia de recurso no-software (CC) , y un archivo index.html.
La página incluye recursos js como cambio de imágenes al hacer click, un objeto en movimiento o un campo de texto que cambia. Su estética esta inspirada en la página: 
<a href="https://elpais.com/especiales/2019/el-co2-en-el-cambio-climatico/" title="Enlace a la página. Abre ventana nueva" target="_blank" > El CO2 en el cambio climático. </a>

Podeis visitar la web que he creado en el siguiente enlace: https://laurafb14.github.io/bioweb-proyecto-tic/
